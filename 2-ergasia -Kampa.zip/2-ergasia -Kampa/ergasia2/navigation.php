<nav style= "background-color: #B3A492;">
    <div class="logo">
        <img src="images/logo.jpg" alt="Λογότυπο">
    </div>
    <ul>
        <li><a href="index.php">Αρχική</a></li>
        <li><a href="login.php">Σύνδεση</a></li>
        <li><a href="register.php">Εγγραφή</a></li>
    </ul><br>
</nav>